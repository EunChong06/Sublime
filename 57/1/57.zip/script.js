
	function q(){	
		function a(){
			$("#q").fadeToggle();
		}
		setTimeout(a,1000);

		function s(){
			$("#w").fadeToggle();
		}
		setTimeout(s,2000);

		function d(){
			$("#e").fadeToggle();
		}
		setTimeout(d,3000);

		function f(){
			$("#r").fadeToggle();
		}
		setTimeout(f,4000);

		function g(){
			$("#t").fadeToggle();
		}
		setTimeout(g,5000);

		function a(){
			$("#q").fadeToggle();
		}
		setTimeout(a,6000);

		function s(){
			$("#w").fadeToggle();
		}
		setTimeout(s,7000);

		function d(){
			$("#e").fadeToggle();
		}
		setTimeout(d,8000);

		function f(){
			$("#r").fadeToggle();
		}
		setTimeout(f,9000);

		function g(){
			$("#t").fadeToggle();
		}
		setTimeout(g,10000);
}
setInterval(q,10000)

