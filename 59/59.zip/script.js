    function h(){		
		function a(){
			$("#q").css({"width":"150","margin-top":"300px","transition":"1s"});
		}
		setTimeout(a,1000);

		 function s(){
		 	$("#w").css({"margin-top":"400px","margin-left":"450px","opacity":"1","transition":"1s"});
		 }
		 setTimeout(s,1000);

		 function d(){
		 	$("#e").css({"margin-top":"400px","margin-left":"450px","opacity":"1","transition":"1s"});
		 }
		 setTimeout(d,2000);

		 function f(){
		 	$("#r").css({"margin-top":"400px","margin-left":"450px","opacity":"1","transition":"1s"});
		 }
		 setTimeout(f,3000);
	}
	setTimeout(h,3000);

	function g(){
		function a(){
			$("#q").css({"width":"100","margin-top":"100px","transition":"1s"});
		}
		setTimeout(a,1200);	

		function s(){
		 	$("#w").css({"margin-top":"600px","margin-left":"200px","opacity":"0.1","transition":"1s"});
		 }
		 setTimeout(s,1200);

		function d(){
		 	$("#e").css({"margin-top":"600px","margin-left":"200px","opacity":"0.1","transition":"1s"});
		 }
		 setTimeout(d,2200);

		function f(){
		 	$("#r").css({"margin-top":"600px","margin-left":"200px","opacity":"0.1","transition":"1s"});
		 }
		 setTimeout(f,3200);
	} 
	setTimeout(g,3200);