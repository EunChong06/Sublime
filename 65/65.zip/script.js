function cloud(){
	$("#h").css({"margin-left":"410px","transition":"10s","opacity":"0"});
}
setTimeout(cloud,1000);

function sun(){
	$("#g").css({"margin-left":"410px","transition":"15s","opacity":"0"});
}
setTimeout(sun,1000);

 function background(){
 	$("#q").css({"background-color":"#71289e","transition":"1s"});
 }
 setTimeout(background,5000);

  function o(){
 	$("#o").css({"background-color":"#9136c9","transition":"1s"});
 }
 setTimeout(o,5000);

  function i(){
 	$("#i").css({"background-color":"#621294","transition":"1s"});
 }
 setTimeout(i,5000);

   function w(){
 	$("#w").css({"background-color":"#3d1457","transition":"1s"});
 }
 setTimeout(w,5000);

   function e(){
 	$("#e").css({"background-color":"#3d1457","transition":"1s"});
 }
 setTimeout(e,5000);


   function r(){
 	$("#r").css({"background-color":"#3d1457","transition":"1s"});
 }
 setTimeout(r,5000);

   function t(){
 	$("#t").css({"background-color":"#3d1457","transition":"1s"});
 }
 setTimeout(t,5000);

   function y(){
 	$("#y").css({"background-color":"#3d1457","transition":"1s"});
 }
 setTimeout(y,5000);

    function p(){
 	$("#p").css({"background-color":"#890dd6","transition":"1s"});
 }
 setTimeout(p,5000);

    function a(){
 	$("#a").css({"background-color":"#890dd6","transition":"1s"});
 }
 setTimeout(a,5000);

    function s(){
 	$("#s").css({"background-color":"#890dd6","transition":"1s"});
 }
 setTimeout(s,5000);

    function d(){
 	$("#d").css({"background-color":"#890dd6","transition":"1s"});
 }
 setTimeout(d,5000);

    function f(){
 	$("#f").css({"background-color":"#890dd6","transition":"1s"});
 }
 setTimeout(f,5000);